

<!-- Declaração do tipo de documento html. Neste caso é HTML5 -->
<!doctype html>

<!-- importante! Definir a linguagem da página WEB -->
<html lang="pt-br">

<head>

    <meta charset="utf-8" />
	<!-- tem que ter em php aqui se não não estava funcionando -->
	
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="-1" />

    <meta name="description" 
 content="Nesta página veremos como implementar um formulário HTML5 com bootstrap e diversas  " />
    <meta name="author" content="" />

    <title>Trabalhando com formulários HTML - dicas especiais</title>

    <!-- Bootstrap Core CSS -->
   <!-- Usar versão CSS compilada e minificada -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">


<!-- Com a tag link geralmente apontamos para arquivos css do seu site
 ou de outros sites como o CDN do bootstrap acima -->
<!-- o css externo -->
<link  href="cssexterno.css" rel="stylesheet" >


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	
<style>	
	
        
	#page-content-wrapper{
	position:relative;
	top:25px;

	}

	body {
		word-wrap: break-word;
	}
	.secao-cronograma{
	font-weight:bolder;

	}

	form{font-weight:bolder;}
		
	.panel-title{
			
	   font-size: 2.0rem;
	}
        
</style>

	
</head>

<body  >

<div class="container-fluid header">
 <!-- -->
				
		

<!-- Page Content -->
        <div id="page-content-wrapper">

<!--  -->

<div class="container-fluid">

<!-- abaixo é como eu acrescento uma linha em branco
Não costumo usar <br /> quando uso bootstrap.
 -->
<div class="row">
	<div class="col-md-12">
	&nbsp;
	</div> <!-- fim col -->
</div>

<div class="row">&nbsp;</div>


	<div class="panel panel-info">
  <div class="panel-heading">
    <h1 class="panel-title" style="font-size: 2.5rem;">CADASTRAR PROJETO INOVADOR</h1>
  </div>
  <div class="panel-body " style="background-color:#d9edf7;">

  
    <div class="row">
	
    <div class="col-md-8">
	<!-- data-validate -->
	<form name="formenvio" id="formenvio" action="" class="form-horizontal"   method="post">

	
<div class="row">	<!-- class="col-xs-4 regula o tamanho da div e col-xs-offset-4-->
	<div class="col-xs-8 col-xs-offset-2">
		<div class="alert alert-warning output hidden">&nbsp;</div>
	</div>
</div>	
	


<?php

//A forma correta para pegar o valor do campo simnao
//seria através de um select com o o valor do 
//campo de status simnao na base de dados

$simnao="1";
 ?>
	
		
<div class="panel panel-success">
  <div class="panel-heading">
    <h2 class="panel-title" style="font-size: 2.0rem;">O projeto é em dupla?</h2>
  </div>
  <div class="panel-body " style="background-color:#dff0d8">
<div class="container">
<div class="form-group">	
	<div class="">
      <div class="radio ">
        <label class="  " >
          <input <?php if ($simnao==="1"){ echo " checked ";} ?> type="radio" name="simnao" id="sim" data-required  
		  data-msg="O campo você tem parceiro para o processo é requerido."  
		  value="1" ><span style="font-weight:bolder;">Sim</span>
        </label>
      </div>
    </div>
  </div>
<div class="form-group">	
  <div class="">
      <div class="radio ">
        <label class="  " >
          <input <?php if ($simnao==="0"){ echo " checked ";} ?> type="radio" name="simnao" id="nao" data-required  
		  data-msg=""  value="0" ><span style="font-weight:bolder;">Não</span>
        </label>
      </div>
    </div>
  </div>
  
  


 </div> 
	
  </div> <!-- fim panelbody -->
</div> <!-- fim panel -->

  
  	 <div class="inclusaovalores">
	 <!-- O código abaixo é para usar com php ou outra linguagem
	 Caso no banco de dados já tenha sido cadastrado anteriormente
	 pelo botão salvar como tem paceiro $simnao terá valor 1 e a
	 div com a matricula do usuário será exibida
	 permitindo a alteração do valor -->

	 <?php 
	
	 if ($simnao==="1")
	 { 
	?>
	  <div class="form-group has-success "><label for="matricula_colega"  class="col-sm-2 control-label ">Matrícula do colega: </label>
<div class="col-sm-9"><input  type="text" value="x15863" maxlenght="7" data-rule="usrempresa" class="form-control " placeholder="matrícula do colega com até 6 caracteres no formato X12345." 
data-required data-msg="O campo matrícula do colega é obrigatório e deve ser preenchido no formato X12345." id="matricula_colega" name="matricula_colega" ></div></div>
	 <?php }  ?>
	 
	 </div>


 




  <hr />
    <div class="container">
  <div class="form-group ">
		<div class="has-success ">
      <div class="checkbox ">
        <label>
          <input name="termo_responsabilidade"  data-required 
          data-msg='O campo do "Termo de Responsabilidade" é de preenchimento obrigatório.'
		  value="1" type="checkbox"> <span><strong>Certifico que li os Termos e Condições e<br />
		   Responsabilizo-me pelas informações prestadas.<span></strong>
        </label>
      </div>
	  </div>
    </div>
	</div>

	
<div class="row">
<?php

//Aqui usamos uma condição negativa
//se a data atual não for maior
//que a data informada, mostra os botões

 if (!(strtotime("today") > strtotime("10/25/2018"))){
    
?>
	<div class="col-sm-2">
		  <div  class="form-group">
			<div class="col-sm-2 ">
			  <button id="salvaformprincipal" data-salvacadastra="0" 
			  data-tooltip title="Salva os dados para envio futuro."  
			  type="button"  class="btn btn-info btn-lg">Salvar</button> 
			</div> 
		  </div>
	 </div>
	  
	  <div class="col-sm-2">
		  <div  class="form-group">
			<div class="col-sm-2 ">
			  <button id="cadastraformprincipal" data-salvacadastra="1" 
			  data-tooltip title="Use este botão para cadastrar sua ideia."  
			  type="button"  class="btn btn-info btn-lg">Cadastrar</button> 
			</div> 
		  </div>
	  </div>
	  
	  <input type='hidden' name = "verificabotao" id="verificabotao" value="" /> 

<?php
}//Essa é a mensagem que aparece 
//que  a data já passou.informa que
//o periodo de votação já encerrou, 
//pois a data do dia atual é maior
// que o 2º parametro
else{
?>

<span class="col-md-6 col-md-offset-1" style="font-size:200%;font-weight:bold;color:red">O per&iacute;odo de cadastro foi encerrado.</span>
<?php
}
?>
  
</div>
  

</form>
	
	
	</div>

	
	</div>
	
  </div> <!-- fim panelbody principal-->
</div> <!-- fim panel principal -->


</div> <!-- container -->
		
<!-- Abaixo mostra mensagem, caso o navegador
seja o internet explorer, para o usuário escolher
outro navegador. Caso seja necessário em seus projetos.
 -->		
		
<script type="text/javascript">

 //var ie = /*@cc_on!@*/false || !!document.documentMode;  //outra forma
 var ie = /msie|trident/g.test(navigator.userAgent.toLowerCase());
 
 //abaixo serve para o edge tb
//alert(/msie|trident|edge/g.test(navigator.userAgent.toLowerCase()));
 
 //var verseie = /msie|trident/g.test(navigator.userAgent.toLowerCase());
if (ie){
document.write('<div class=" "><strong><span style="color:red" id="helpBlock" class="help-block">O Internet Explorer não suporta algumas tecnologias inovadoras. Sugerimos utilizar outro navegador.</span></strong></div>');
          
}
</script>

<!-- js -->

	

</div> <!-- fim  Page Content  id="page-content-wrapper 	-->
	
	
	<!-- jQuery -->
<script
  src="https://code.jquery.com/jquery-3.3.1.min.js" 
  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" 
  crossorigin="anonymous"></script>

	<!-- Bootstrap Core JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>	


            
</div> <!--<div class="container-fluid"> -->
 

<script src="jsexterno.js"></script>

<script type="text/javascript">

$(document).ready(function(){
//notify('ii');
//alert("cx");



$("#sim").click(function(){

$(".inclusaovalores").html("");

$(".inclusaovalores").html($(".inclusaovalores").html() + '<div class="form-group has-success "><label for="matricula_colega"  class="col-sm-2 control-label ">Matrícula do colega: </label>'+
'<div class="col-sm-9"><input  type="text" value="" maxlenght="7" data-rule="usrempresa" class="form-control " placeholder="matrícula do colega com até 6 caracteres no formato X12345."'+
'data-required data-msg="O campo matrícula do colega é obrigatório e deve ser preenchido no formato X12345." id="matricula_colega" name="matricula_colega" ></div></div>');

});


$("#nao").click(function(){

	$(".inclusaovalores").html("");		

});

	//aqui eu pensei, já que os dois botões fazem a
	// mesma coisa, pq não ter uma função só
	//aí pensei em pesquisar no google. Jquery 
	//como selecionar 2 elementos. só achei besteira.
	//aí coloquei jquery how to select two elements. 
	//o primeiro resultado já resolveu meu problema
	//https://api.jquery.com/multiple-selector/
	
	$('#cadastraformprincipal,#salvaformprincipal').on('click', function(e){
		//executa as mesmas coisas ao selecionar ou
		//o botão salvar ou o botão enviar				

		//pega o botão clicado
		var btn = jQuery(this);		
			
			//qual for o botão
			//põe o valor do atributo data-salvacadastra
			//do botão clicado como o valor do input
			//hidden de id=verificabotao
			$('#verificabotao').val(btn.data("salvacadastra"));
			
			//valida no js externo
			validateClick($($(this).closest("form")));
		//}
		//alert($('#verificabotao').val());
	
		
	
  });	
	
		
});

</script>            

</body>


</html>






